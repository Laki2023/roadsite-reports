-- =====================================================
-- RoadSite Reports V7 - Supabase Schema
-- Run this in the Supabase SQL Editor
-- =====================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  title TEXT,
  profession TEXT,
  role TEXT DEFAULT 'pending' CHECK (role IN ('pending','inspector','re','engineer','pm','admin','super_admin')),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
-- Admin updates handled via service role or separate policy
CREATE POLICY "Admins can update any profile" ON profiles FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin'))
);

-- ============ PROJECTS ============
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  contract_no TEXT,
  contractor TEXT,
  consultant TEXT,
  category TEXT DEFAULT 'Construction',
  fidic_edition TEXT,
  contract_sum NUMERIC,
  county TEXT,
  road_class TEXT,
  chainage_start NUMERIC,
  chainage_end NUMERIC,
  start_date DATE,
  end_date DATE,
  status TEXT DEFAULT 'Active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view projects" ON projects FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage projects" ON projects FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ DAILY REPORTS ============
CREATE TABLE IF NOT EXISTS daily_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  submitted_by UUID REFERENCES profiles(id),
  report_date DATE NOT NULL,
  weather_morning TEXT,
  weather_afternoon TEXT,
  temperature_high NUMERIC,
  temperature_low NUMERIC,
  shift_type TEXT DEFAULT 'Day',
  general_remarks TEXT,
  visitors TEXT,
  safety_incidents TEXT,
  instructions_received TEXT,
  labour_summary JSONB,
  materials_received TEXT,
  status TEXT DEFAULT 'submitted',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view reports" ON daily_reports FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert reports" ON daily_reports FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ WORKS ACTIVITIES (master list per project) ============
CREATE TABLE IF NOT EXISTS works_activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  unit TEXT,
  boq_quantity NUMERIC,
  sort_order INTEGER DEFAULT 0,
  status TEXT DEFAULT 'Not Started',
  percent_complete NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE works_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view works_activities" ON works_activities FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage works_activities" ON works_activities FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ WORKS PROGRESS (daily entries from reports) ============
CREATE TABLE IF NOT EXISTS works_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES works_activities(id) ON DELETE SET NULL,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  report_date DATE,
  activity_name TEXT,
  chainage_from NUMERIC,
  chainage_to NUMERIC,
  side TEXT,
  quantity_today NUMERIC DEFAULT 0,
  unit TEXT,
  equipment_used TEXT,
  materials_used TEXT,
  gang_size INTEGER,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE works_progress ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view works_progress" ON works_progress FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert works_progress" ON works_progress FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ EQUIPMENT REGISTER (master list per project) ============
CREATE TABLE IF NOT EXISTS equipment_register (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  equipment_type TEXT NOT NULL,
  make TEXT,
  model TEXT,
  reg_no TEXT,
  capacity TEXT,
  required_qty INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE equipment_register ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view equipment_register" ON equipment_register FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage equipment_register" ON equipment_register FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ EQUIPMENT DAILY STATUS (from reports) ============
CREATE TABLE IF NOT EXISTS equipment_daily_status (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  equipment_id UUID REFERENCES equipment_register(id) ON DELETE SET NULL,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  status_date DATE,
  equipment_name TEXT,
  status TEXT DEFAULT 'Operational',
  hours_worked NUMERIC DEFAULT 0,
  fuel_litres NUMERIC,
  operator_name TEXT,
  location_chainage TEXT,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE equipment_daily_status ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view equipment_daily_status" ON equipment_daily_status FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert equipment_daily_status" ON equipment_daily_status FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ STRUCTURES (master list per project) ============
CREATE TABLE IF NOT EXISTS structures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  structure_type TEXT NOT NULL,
  structure_ref TEXT,
  chainage NUMERIC,
  side TEXT DEFAULT 'CL',
  span_m NUMERIC,
  no_of_cells INTEGER DEFAULT 1,
  concrete_grade TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE structures ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view structures" ON structures FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage structures" ON structures FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ STRUCTURE PROGRESS (from reports) ============
CREATE TABLE IF NOT EXISTS structure_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  structure_id UUID REFERENCES structures(id) ON DELETE SET NULL,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  stage TEXT NOT NULL,
  work_date DATE,
  structure_name TEXT,
  description TEXT,
  quantity NUMERIC,
  unit TEXT,
  crew_size INTEGER,
  concrete_volume NUMERIC,
  concrete_grade TEXT,
  rebar_tonnes NUMERIC,
  formwork_sqm NUMERIC,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE structure_progress ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view structure_progress" ON structure_progress FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert structure_progress" ON structure_progress FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ PAVEMENT LAYERS (from reports) ============
CREATE TABLE IF NOT EXISTS pavement_layers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  layer_type TEXT NOT NULL,
  chainage_from NUMERIC,
  chainage_to NUMERIC,
  side TEXT DEFAULT 'Full',
  width_m NUMERIC,
  thickness_mm NUMERIC,
  material_source TEXT,
  material_type TEXT,
  compaction_status TEXT,
  status TEXT DEFAULT 'In Progress',
  work_date DATE,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE pavement_layers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view pavement_layers" ON pavement_layers FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert pavement_layers" ON pavement_layers FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ QUALITY TESTS (from reports) ============
CREATE TABLE IF NOT EXISTS quality_tests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  test_type TEXT NOT NULL,
  layer_type TEXT,
  chainage TEXT,
  side TEXT,
  sample_ref TEXT,
  test_date DATE,
  result_value NUMERIC,
  result_unit TEXT,
  spec_min NUMERIC,
  spec_max NUMERIC,
  assessment TEXT,
  tested_by TEXT,
  lab_ref TEXT,
  remarks TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE quality_tests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view quality_tests" ON quality_tests FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert quality_tests" ON quality_tests FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- ============ SITE ISSUES (from reports) ============
CREATE TABLE IF NOT EXISTS site_issues (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  report_id UUID REFERENCES daily_reports(id) ON DELETE CASCADE,
  category TEXT DEFAULT 'General',
  severity TEXT DEFAULT 'Medium',
  chainage TEXT,
  description TEXT NOT NULL,
  action_required TEXT,
  reported_by UUID REFERENCES profiles(id),
  reported_date DATE,
  status TEXT DEFAULT 'Open',
  resolved_date DATE,
  is_emergency BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE site_issues ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view site_issues" ON site_issues FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can insert site_issues" ON site_issues FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Admins can update site_issues" ON site_issues FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ CONTRACT DOCUMENTS ============
CREATE TABLE IF NOT EXISTS contract_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  doc_type TEXT,
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT,
  uploaded_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE contract_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view contract_documents" ON contract_documents FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage contract_documents" ON contract_documents FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin','pm','engineer','re'))
);

-- ============ MAKE FIRST USER SUPER_ADMIN ============
-- After registering your first user, run:
-- UPDATE profiles SET role = 'super_admin' WHERE email = 'collinslaki@gmail.com';
