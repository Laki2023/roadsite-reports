import React, { useState, useEffect, useCallback } from 'react';
import { supabase, getProfile, getEmergencyAlerts } from './lib/supabase';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import SubmitReport from './pages/SubmitReport';
import ReportsPage from './pages/ReportsPage';
import ProjectsPage from './pages/ProjectsPage';
import WorksActivitiesPage from './pages/WorksActivitiesPage';
import EquipmentPage from './pages/EquipmentPage';
import StructuresPage from './pages/StructuresPage';
import PavementLayersPage from './pages/PavementLayersPage';
import QualityTestsPage from './pages/QualityTestsPage';
import SiteIssuesPage from './pages/SiteIssuesPage';
import AdminPanel from './pages/AdminPanel';

const ROLE_HIERARCHY = { 'super_admin': 6, 'admin': 5, 'pm': 4, 'engineer': 3, 're': 2, 'inspector': 1, 'pending': 0 };
function hasRole(userRole, minRole) {
  return (ROLE_HIERARCHY[userRole] || 0) >= (ROLE_HIERARCHY[minRole] || 0);
}

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) loadProfile(session.user.id);
      else setLoading(false);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setSession(session);
      if (session) loadProfile(session.user.id);
      else { setProfile(null); setLoading(false); }
    });
    return () => subscription.unsubscribe();
  }, []);

  async function loadProfile(userId) {
    try {
      const p = await getProfile(userId);
      setProfile(p);
    } catch { setProfile(null); }
    setLoading(false);
  }

  const loadAlerts = useCallback(async () => {
    try {
      const a = await getEmergencyAlerts();
      setAlerts(a);
    } catch {}
  }, []);

  useEffect(() => {
    if (profile && hasRole(profile.role, 'inspector')) {
      loadAlerts();
      const interval = setInterval(loadAlerts, 30000);
      return () => clearInterval(interval);
    }
  }, [profile, loadAlerts]);

  if (loading) return <div className="loading-screen"><div className="spinner" /><p>Loading RoadSite Reports...</p></div>;
  if (!session) return <AuthPage />;
  if (!profile || profile.role === 'pending') return (
    <div className="pending-screen">
      <div className="pending-card">
        <h2>⏳ Account Pending Approval</h2>
        <p>Your registration is awaiting approval from an administrator. You'll receive access once your account is activated.</p>
        <button onClick={() => supabase.auth.signOut()} className="btn btn-secondary">Sign Out</button>
      </div>
    </div>
  );

  const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊', minRole: 'inspector' },
    { id: 'submit-report', label: 'Submit Report', icon: '📝', minRole: 'inspector' },
    { id: 'reports', label: 'View Reports', icon: '📋', minRole: 'inspector' },
    { id: 'divider-1', divider: true, label: 'ROAD ENGINEERING' },
    { id: 'works', label: 'Works Activities', icon: '⛏️', minRole: 'inspector' },
    { id: 'equipment', label: 'Equipment', icon: '🚜', minRole: 'inspector' },
    { id: 'structures', label: 'Structures', icon: '🌉', minRole: 'inspector' },
    { id: 'pavement', label: 'Pavement Layers', icon: '🛣️', minRole: 'inspector' },
    { id: 'quality', label: 'Quality Tests', icon: '🧪', minRole: 'inspector' },
    { id: 'issues', label: 'Site Issues', icon: '⚠️', minRole: 'inspector' },
    { id: 'divider-2', divider: true, label: 'MANAGEMENT' },
    { id: 'projects', label: 'Projects', icon: '🏗️', minRole: 're' },
    { id: 'admin', label: 'Admin Panel', icon: '⚙️', minRole: 'admin' },
  ];

  const renderPage = () => {
    const props = { profile, setPage };
    switch (page) {
      case 'dashboard': return <Dashboard {...props} alerts={alerts} />;
      case 'submit-report': return <SubmitReport {...props} />;
      case 'reports': return <ReportsPage {...props} />;
      case 'works': return <WorksActivitiesPage {...props} />;
      case 'equipment': return <EquipmentPage {...props} />;
      case 'structures': return <StructuresPage {...props} />;
      case 'pavement': return <PavementLayersPage {...props} />;
      case 'quality': return <QualityTestsPage {...props} />;
      case 'issues': return <SiteIssuesPage {...props} />;
      case 'projects': return <ProjectsPage {...props} />;
      case 'admin': return <AdminPanel {...props} />;
      default: return <Dashboard {...props} alerts={alerts} />;
    }
  };

  return (
    <div className="app-layout">
      {alerts.length > 0 && (
        <div className="emergency-banner">
          🚨 {alerts.length} EMERGENCY ALERT{alerts.length > 1 ? 'S' : ''} — {alerts[0]?.description?.substring(0, 60)}...
          <button onClick={() => setPage('issues')} className="alert-btn">View</button>
        </div>
      )}

      <header className="top-bar">
        <button className="hamburger" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
        <h1 className="app-title">🚧 RoadSite Reports</h1>
        <div className="user-info">
          <span className="user-name">{profile.full_name}</span>
          <span className="user-role">{profile.role.toUpperCase()}</span>
          <button onClick={() => supabase.auth.signOut()} className="btn-signout">Sign Out</button>
        </div>
      </header>

      <div className="main-container">
        <nav className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          {NAV_ITEMS.map(item => {
            if (item.divider) return <div key={item.id} className="nav-divider">{item.label}</div>;
            if (!hasRole(profile.role, item.minRole)) return null;
            return (
              <button key={item.id}
                className={`nav-item ${page === item.id ? 'active' : ''}`}
                onClick={() => { setPage(item.id); setSidebarOpen(false); }}>
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <main className="content" onClick={() => sidebarOpen && setSidebarOpen(false)}>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
