import React, { useState, useEffect } from 'react';
import { getProjects, getEquipmentRegister, getEquipmentDailyStatus, addEquipment } from '../lib/supabase';

export default function EquipmentPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [equipment, setEquipment] = useState([]);
  const [dailyStatus, setDailyStatus] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newEq, setNewEq] = useState({ equipment_type: '', make: '', model: '', reg_no: '', capacity: '', required_qty: 1 });
  const isAdmin = ['admin', 'super_admin', 'pm', 'engineer'].includes(profile.role);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);
  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      Promise.all([getEquipmentRegister(selectedProject), getEquipmentDailyStatus(selectedProject)])
        .then(([e, d]) => { setEquipment(e); setDailyStatus(d); })
        .catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  async function handleAdd() {
    try {
      await addEquipment({ ...newEq, project_id: selectedProject });
      const e = await getEquipmentRegister(selectedProject);
      setEquipment(e);
      setShowAdd(false);
      setNewEq({ equipment_type: '', make: '', model: '', reg_no: '', capacity: '', required_qty: 1 });
    } catch (err) { alert(err.message); }
  }

  const eqWithStatus = equipment.map(eq => {
    const statuses = dailyStatus.filter(d => d.equipment_id === eq.id);
    const latest = statuses[0];
    const totalHours = statuses.reduce((s, d) => s + (parseFloat(d.hours_worked) || 0), 0);
    const totalFuel = statuses.reduce((s, d) => s + (parseFloat(d.fuel_litres) || 0), 0);
    return { ...eq, latestStatus: latest?.status || '-', totalHours, totalFuel, entries: statuses.length };
  });

  const operational = eqWithStatus.filter(e => e.latestStatus === 'Operational').length;
  const total = eqWithStatus.length;

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>🚜 Equipment Register</h2>
        <p className="page-subtitle">Read-only status dashboard — daily entries come from site reports</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {isAdmin && selectedProject && <button className="btn btn-primary" onClick={() => setShowAdd(!showAdd)}>+ Add Equipment</button>}
      </div>

      {showAdd && (
        <div className="entry-card" style={{ marginBottom: 20 }}>
          <h4>Add Equipment to Register</h4>
          <div className="form-row">
            <div className="form-group"><label>Type</label><input value={newEq.equipment_type} onChange={e => setNewEq(p => ({ ...p, equipment_type: e.target.value }))} placeholder="Motor Grader" /></div>
            <div className="form-group"><label>Make</label><input value={newEq.make} onChange={e => setNewEq(p => ({ ...p, make: e.target.value }))} placeholder="CAT" /></div>
            <div className="form-group"><label>Model</label><input value={newEq.model} onChange={e => setNewEq(p => ({ ...p, model: e.target.value }))} placeholder="140H" /></div>
            <div className="form-group"><label>Reg No.</label><input value={newEq.reg_no} onChange={e => setNewEq(p => ({ ...p, reg_no: e.target.value }))} placeholder="KBZ 123A" /></div>
          </div>
          <button className="btn btn-primary" onClick={handleAdd}>Save</button>
        </div>
      )}

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view equipment.</p>
      ) : equipment.length === 0 ? (
        <p className="empty">No equipment registered. {isAdmin ? 'Add equipment using the button above.' : ''}</p>
      ) : (
        <>
          <div className="stats-grid" style={{ marginBottom: 20 }}>
            <div className="stat-card"><div className="stat-value">{total}</div><div className="stat-label">Total Fleet</div></div>
            <div className="stat-card"><div className="stat-value">{operational}</div><div className="stat-label">Operational</div></div>
            <div className="stat-card"><div className="stat-value">{total > 0 ? Math.round(operational / total * 100) : 0}%</div><div className="stat-label">Availability</div></div>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Equipment</th><th>Make/Model</th><th>Reg No.</th><th>Current Status</th><th>Total Hours</th><th>Total Fuel (L)</th><th>Reports</th></tr></thead>
              <tbody>
                {eqWithStatus.map(e => (
                  <tr key={e.id}>
                    <td><strong>{e.equipment_type}</strong></td>
                    <td>{e.make} {e.model}</td>
                    <td>{e.reg_no}</td>
                    <td><span className={`status-badge status-${e.latestStatus.toLowerCase().replace(/\s/g, '-')}`}>{e.latestStatus}</span></td>
                    <td>{e.totalHours > 0 ? e.totalHours.toFixed(1) : '-'}</td>
                    <td>{e.totalFuel > 0 ? e.totalFuel.toFixed(0) : '-'}</td>
                    <td>{e.entries}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
