import React, { useState, useEffect } from 'react';
import {
  getProjects, getWorksActivities, getEquipmentRegister, getStructures,
  submitDailyReport, getKenyaRDMSpecs, assessTestResult
} from '../lib/supabase';

const WEATHER_OPTIONS = ['Sunny', 'Partly Cloudy', 'Overcast', 'Light Rain', 'Heavy Rain', 'Stormy'];
const LAYER_TYPES = ['Subgrade', 'Improved Subgrade', 'Sub-base', 'Base', 'Binder Course', 'Wearing Course', 'Prime Coat', 'Tack Coat', 'Seal'];
const TEST_TYPES = ['CBR', 'MDD', 'Compaction', 'DCP', 'Gradation', 'Plasticity Index', 'Liquid Limit', 'Linear Shrinkage', 'Swell', 'LAA', 'Flakiness Index', 'Aggregate Crushing Value', 'Sand Equivalent', 'Marshall Stability', 'Marshall Flow', 'Air Voids', 'VMA', 'Bitumen Content', 'GMB', 'Benkelman Beam Deflection', 'Roughness (IRI)', 'Texture Depth', 'Skid Resistance', 'Permeability'];
const ISSUE_CATEGORIES = ['Safety', 'Quality', 'Environmental', 'Design', 'Material', 'Equipment', 'Labour', 'Weather', 'Access', 'Utility', 'Community', 'Contractual', 'General'];
const STRUCTURE_STAGES = ['Setting Out', 'Excavation', 'Blinding', 'Foundation/Base Slab', 'Base Reinforcement', 'Base Concrete', 'Wall Formwork', 'Wall Reinforcement', 'Wall Concrete', 'Top Slab Formwork', 'Top Slab Reinforcement', 'Top Slab Concrete', 'Headwall', 'Wingwall', 'Apron', 'Backfilling', 'Scour Protection', 'Waterproofing'];

export default function SubmitReport({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [projectActivities, setProjectActivities] = useState([]);
  const [projectEquipment, setProjectEquipment] = useState([]);
  const [projectStructures, setProjectStructures] = useState([]);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  // Collapsible section state
  const [openSections, setOpenSections] = useState({ general: true });

  // GENERAL INFO
  const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);
  const [weatherMorning, setWeatherMorning] = useState('');
  const [weatherAfternoon, setWeatherAfternoon] = useState('');
  const [tempHigh, setTempHigh] = useState('');
  const [tempLow, setTempLow] = useState('');
  const [shiftType, setShiftType] = useState('Day');
  const [generalRemarks, setGeneralRemarks] = useState('');
  const [visitors, setVisitors] = useState('');
  const [safetyIncidents, setSafetyIncidents] = useState('');
  const [instructions, setInstructions] = useState('');

  // WORKS ACTIVITIES
  const [worksEntries, setWorksEntries] = useState([]);
  // EQUIPMENT
  const [equipEntries, setEquipEntries] = useState([]);
  // STRUCTURES
  const [structEntries, setStructEntries] = useState([]);
  // PAVEMENT
  const [pavementEntries, setPavementEntries] = useState([]);
  // QUALITY TESTS
  const [testEntries, setTestEntries] = useState([]);
  // SITE ISSUES
  const [issueEntries, setIssueEntries] = useState([]);
  // LABOUR
  const [labourSummary, setLabourSummary] = useState({ skilled: '', unskilled: '', supervisors: '', total: '' });
  // MATERIALS
  const [materialsReceived, setMaterialsReceived] = useState('');

  useEffect(() => {
    getProjects().then(setProjects).catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedProject) {
      getWorksActivities(selectedProject).then(setProjectActivities).catch(() => setProjectActivities([]));
      getEquipmentRegister(selectedProject).then(setProjectEquipment).catch(() => setProjectEquipment([]));
      getStructures(selectedProject).then(setProjectStructures).catch(() => setProjectStructures([]));
    }
  }, [selectedProject]);

  function toggleSection(key) {
    setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
  }

  function addWorksEntry() {
    setWorksEntries(prev => [...prev, { activity_id: '', activity_name: '', chainage_from: '', chainage_to: '', side: 'CL', quantity_today: '', unit: '', equipment_used: '', gang_size: '', remarks: '' }]);
  }
  function removeWorksEntry(i) { setWorksEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updateWorksEntry(i, field, val) {
    setWorksEntries(prev => {
      const n = [...prev];
      n[i] = { ...n[i], [field]: val };
      if (field === 'activity_id' && val) {
        const act = projectActivities.find(a => a.id === val);
        if (act) { n[i].activity_name = act.name; n[i].unit = act.unit; }
      }
      return n;
    });
  }

  function addEquipEntry() {
    setEquipEntries(prev => [...prev, { equipment_id: '', equipment_name: '', status: 'Operational', hours_worked: '', fuel_litres: '', operator_name: '', location_chainage: '', remarks: '' }]);
  }
  function removeEquipEntry(i) { setEquipEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updateEquipEntry(i, field, val) {
    setEquipEntries(prev => {
      const n = [...prev];
      n[i] = { ...n[i], [field]: val };
      if (field === 'equipment_id' && val) {
        const eq = projectEquipment.find(e => e.id === val);
        if (eq) n[i].equipment_name = eq.equipment_type + ' - ' + (eq.make || '') + ' ' + (eq.reg_no || '');
      }
      return n;
    });
  }

  function addStructEntry() {
    setStructEntries(prev => [...prev, { structure_id: '', structure_name: '', stage: '', description: '', quantity: '', unit: '', crew_size: '', concrete_volume: '', concrete_grade: '', rebar_tonnes: '', remarks: '' }]);
  }
  function removeStructEntry(i) { setStructEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updateStructEntry(i, field, val) {
    setStructEntries(prev => {
      const n = [...prev];
      n[i] = { ...n[i], [field]: val };
      if (field === 'structure_id' && val) {
        const s = projectStructures.find(s => s.id === val);
        if (s) n[i].structure_name = s.structure_ref + ' (' + s.structure_type + ')';
      }
      return n;
    });
  }

  function addPavementEntry() {
    setPavementEntries(prev => [...prev, { layer_type: '', chainage_from: '', chainage_to: '', side: 'Full', width_m: '', thickness_mm: '', material_source: '', material_type: '', compaction_status: '', status: 'In Progress', remarks: '' }]);
  }
  function removePavementEntry(i) { setPavementEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updatePavementEntry(i, field, val) {
    setPavementEntries(prev => { const n = [...prev]; n[i] = { ...n[i], [field]: val }; return n; });
  }

  function addTestEntry() {
    setTestEntries(prev => [...prev, { test_type: '', layer_type: '', chainage: '', side: '', sample_ref: '', result_value: '', result_unit: '', spec_min: null, spec_max: null, assessment: '', tested_by: '', lab_ref: '', remarks: '' }]);
  }
  function removeTestEntry(i) { setTestEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updateTestEntry(i, field, val) {
    setTestEntries(prev => {
      const n = [...prev];
      n[i] = { ...n[i], [field]: val };
      if (field === 'test_type' || field === 'layer_type') {
        const tt = field === 'test_type' ? val : n[i].test_type;
        const lt = field === 'layer_type' ? val : n[i].layer_type;
        if (tt && lt) {
          const spec = getKenyaRDMSpecs(tt, lt);
          n[i].spec_min = spec.min;
          n[i].spec_max = spec.max;
          n[i].result_unit = spec.unit || n[i].result_unit;
        }
      }
      if (field === 'result_value') {
        n[i].assessment = assessTestResult(val, n[i].spec_min, n[i].spec_max);
      }
      return n;
    });
  }

  function addIssueEntry() {
    setIssueEntries(prev => [...prev, { category: 'General', severity: 'Medium', chainage: '', description: '', action_required: '', is_emergency: false }]);
  }
  function removeIssueEntry(i) { setIssueEntries(prev => prev.filter((_, idx) => idx !== i)); }
  function updateIssueEntry(i, field, val) {
    setIssueEntries(prev => { const n = [...prev]; n[i] = { ...n[i], [field]: val }; return n; });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!selectedProject) { alert('Please select a project'); return; }
    setSaving(true);
    try {
      await submitDailyReport({
        generalInfo: {
          project_id: selectedProject,
          submitted_by: profile.id,
          report_date: reportDate,
          weather_morning: weatherMorning,
          weather_afternoon: weatherAfternoon,
          temperature_high: tempHigh ? parseFloat(tempHigh) : null,
          temperature_low: tempLow ? parseFloat(tempLow) : null,
          shift_type: shiftType,
          general_remarks: generalRemarks,
          visitors, safety_incidents: safetyIncidents,
          instructions_received: instructions
        },
        worksActivities: worksEntries.filter(w => w.activity_name || w.activity_id),
        equipmentEntries: equipEntries.filter(e => e.equipment_name || e.equipment_id),
        structuresProgress: structEntries.filter(s => s.stage),
        pavementWork: pavementEntries.filter(p => p.layer_type),
        qualityTests: testEntries.filter(t => t.test_type),
        siteIssues: issueEntries.filter(i => i.description),
        labourSummary: (labourSummary.skilled || labourSummary.unskilled) ? labourSummary : null,
        materialsReceived: materialsReceived || null
      });
      setSuccess(true);
      window.scrollTo(0, 0);
    } catch (err) {
      alert('Error submitting report: ' + err.message);
    }
    setSaving(false);
  }

  if (success) return (
    <div className="success-screen">
      <div className="success-card">
        <h2>✅ Report Submitted Successfully</h2>
        <p>Your daily report for <strong>{reportDate}</strong> has been submitted. All engineering modules have been updated automatically.</p>
        <div className="sync-summary">
          {worksEntries.length > 0 && <div className="sync-item">⛏️ {worksEntries.length} works activit{worksEntries.length === 1 ? 'y' : 'ies'} synced</div>}
          {equipEntries.length > 0 && <div className="sync-item">🚜 {equipEntries.length} equipment status{equipEntries.length === 1 ? '' : 'es'} synced</div>}
          {structEntries.length > 0 && <div className="sync-item">🌉 {structEntries.length} structure update{structEntries.length === 1 ? '' : 's'} synced</div>}
          {pavementEntries.length > 0 && <div className="sync-item">🛣️ {pavementEntries.length} pavement entr{pavementEntries.length === 1 ? 'y' : 'ies'} synced</div>}
          {testEntries.length > 0 && <div className="sync-item">🧪 {testEntries.length} quality test{testEntries.length === 1 ? '' : 's'} synced</div>}
          {issueEntries.length > 0 && <div className="sync-item">⚠️ {issueEntries.length} site issue{issueEntries.length === 1 ? '' : 's'} logged</div>}
        </div>
        <button className="btn btn-primary" onClick={() => { setSuccess(false); resetForm(); }}>Submit Another Report</button>
      </div>
    </div>
  );

  function resetForm() {
    setReportDate(new Date().toISOString().split('T')[0]);
    setWeatherMorning(''); setWeatherAfternoon(''); setTempHigh(''); setTempLow('');
    setGeneralRemarks(''); setVisitors(''); setSafetyIncidents(''); setInstructions('');
    setWorksEntries([]); setEquipEntries([]); setStructEntries([]);
    setPavementEntries([]); setTestEntries([]); setIssueEntries([]);
    setLabourSummary({ skilled: '', unskilled: '', supervisors: '', total: '' });
    setMaterialsReceived('');
    setOpenSections({ general: true });
  }

  const sectionCount = (arr) => arr.length > 0 ? ` (${arr.length})` : '';

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>📝 Daily Site Report</h2>
        <p className="page-subtitle">Fill in the sections relevant to today's activities. Only General Info is required — all other sections are optional. Data automatically syncs to engineering modules on submission.</p>
      </div>

      <form onSubmit={handleSubmit}>
        {/* ===== GENERAL INFO (always required) ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.general ? 'open' : ''}`} onClick={() => toggleSection('general')}>
            <span>📋 General Information <span className="required-badge">Required</span></span>
            <span className="toggle-arrow">{openSections.general ? '▼' : '▶'}</span>
          </button>
          {openSections.general && (
            <div className="section-body">
              <div className="form-row">
                <div className="form-group flex-2">
                  <label>Project *</label>
                  <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)} required>
                    <option value="">Select project...</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name} ({p.contract_no || 'No contract'})</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Report Date *</label>
                  <input type="date" value={reportDate} onChange={e => setReportDate(e.target.value)} required />
                </div>
                <div className="form-group">
                  <label>Shift</label>
                  <select value={shiftType} onChange={e => setShiftType(e.target.value)}>
                    <option>Day</option><option>Night</option><option>Both</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Weather (AM)</label>
                  <select value={weatherMorning} onChange={e => setWeatherMorning(e.target.value)}>
                    <option value="">Select...</option>
                    {WEATHER_OPTIONS.map(w => <option key={w}>{w}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Weather (PM)</label>
                  <select value={weatherAfternoon} onChange={e => setWeatherAfternoon(e.target.value)}>
                    <option value="">Select...</option>
                    {WEATHER_OPTIONS.map(w => <option key={w}>{w}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Temp High °C</label>
                  <input type="number" value={tempHigh} onChange={e => setTempHigh(e.target.value)} placeholder="32" />
                </div>
                <div className="form-group">
                  <label>Temp Low °C</label>
                  <input type="number" value={tempLow} onChange={e => setTempLow(e.target.value)} placeholder="18" />
                </div>
              </div>
              <div className="form-group">
                <label>General Remarks / Summary of Day</label>
                <textarea value={generalRemarks} onChange={e => setGeneralRemarks(e.target.value)} rows={3} placeholder="Summary of the day's works..." />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Visitors on Site</label>
                  <textarea value={visitors} onChange={e => setVisitors(e.target.value)} rows={2} placeholder="Name, organization, purpose..." />
                </div>
                <div className="form-group">
                  <label>Safety Incidents</label>
                  <textarea value={safetyIncidents} onChange={e => setSafetyIncidents(e.target.value)} rows={2} placeholder="Any safety incidents or near misses..." />
                </div>
              </div>
              <div className="form-group">
                <label>Instructions from Engineer / Client</label>
                <textarea value={instructions} onChange={e => setInstructions(e.target.value)} rows={2} placeholder="Site instructions received today..." />
              </div>
            </div>
          )}
        </div>

        {/* ===== WORKS ACTIVITIES ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.works ? 'open' : ''}`} onClick={() => toggleSection('works')}>
            <span>⛏️ Works Activities{sectionCount(worksEntries)}</span>
            <span className="toggle-arrow">{openSections.works ? '▼' : '▶'}</span>
          </button>
          {openSections.works && (
            <div className="section-body">
              <p className="section-hint">Record activities progressed today. Select from project activities or type a name for ad-hoc entries.</p>
              {worksEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Activity #{i + 1}</span>
                    <button type="button" className="btn-remove" onClick={() => removeWorksEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group flex-2">
                      <label>Activity</label>
                      {projectActivities.length > 0 ? (
                        <select value={entry.activity_id} onChange={e => updateWorksEntry(i, 'activity_id', e.target.value)}>
                          <option value="">Select activity...</option>
                          {projectActivities.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                        </select>
                      ) : (
                        <input type="text" value={entry.activity_name} onChange={e => updateWorksEntry(i, 'activity_name', e.target.value)} placeholder="Activity name" />
                      )}
                    </div>
                    <div className="form-group">
                      <label>Unit</label>
                      <input type="text" value={entry.unit} onChange={e => updateWorksEntry(i, 'unit', e.target.value)} placeholder="m³, m², km" />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Ch. From</label><input type="number" step="0.001" value={entry.chainage_from} onChange={e => updateWorksEntry(i, 'chainage_from', e.target.value)} placeholder="0+000" /></div>
                    <div className="form-group"><label>Ch. To</label><input type="number" step="0.001" value={entry.chainage_to} onChange={e => updateWorksEntry(i, 'chainage_to', e.target.value)} placeholder="0+500" /></div>
                    <div className="form-group"><label>Side</label>
                      <select value={entry.side} onChange={e => updateWorksEntry(i, 'side', e.target.value)}>
                        <option>CL</option><option>LHS</option><option>RHS</option><option>Both</option>
                      </select>
                    </div>
                    <div className="form-group"><label>Qty Today</label><input type="number" step="0.01" value={entry.quantity_today} onChange={e => updateWorksEntry(i, 'quantity_today', e.target.value)} /></div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Equipment Used</label><input type="text" value={entry.equipment_used} onChange={e => updateWorksEntry(i, 'equipment_used', e.target.value)} placeholder="Grader, Roller..." /></div>
                    <div className="form-group"><label>Gang Size</label><input type="number" value={entry.gang_size} onChange={e => updateWorksEntry(i, 'gang_size', e.target.value)} /></div>
                    <div className="form-group"><label>Remarks</label><input type="text" value={entry.remarks} onChange={e => updateWorksEntry(i, 'remarks', e.target.value)} /></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addWorksEntry}>+ Add Works Activity</button>
            </div>
          )}
        </div>

        {/* ===== EQUIPMENT STATUS ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.equipment ? 'open' : ''}`} onClick={() => toggleSection('equipment')}>
            <span>🚜 Equipment Status{sectionCount(equipEntries)}</span>
            <span className="toggle-arrow">{openSections.equipment ? '▼' : '▶'}</span>
          </button>
          {openSections.equipment && (
            <div className="section-body">
              <p className="section-hint">Record status and utilization of equipment on site today.</p>
              {equipEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Equipment #{i + 1}</span>
                    <button type="button" className="btn-remove" onClick={() => removeEquipEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group flex-2">
                      <label>Equipment</label>
                      {projectEquipment.length > 0 ? (
                        <select value={entry.equipment_id} onChange={e => updateEquipEntry(i, 'equipment_id', e.target.value)}>
                          <option value="">Select equipment...</option>
                          {projectEquipment.map(eq => <option key={eq.id} value={eq.id}>{eq.equipment_type} - {eq.make} {eq.reg_no}</option>)}
                        </select>
                      ) : (
                        <input type="text" value={entry.equipment_name} onChange={e => updateEquipEntry(i, 'equipment_name', e.target.value)} placeholder="e.g. CAT 140H Motor Grader" />
                      )}
                    </div>
                    <div className="form-group">
                      <label>Status</label>
                      <select value={entry.status} onChange={e => updateEquipEntry(i, 'status', e.target.value)}>
                        <option>Operational</option><option>Idle</option><option>Breakdown</option><option>Under Maintenance</option><option>Standby</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Hours Worked</label><input type="number" step="0.5" value={entry.hours_worked} onChange={e => updateEquipEntry(i, 'hours_worked', e.target.value)} /></div>
                    <div className="form-group"><label>Fuel (Litres)</label><input type="number" step="0.1" value={entry.fuel_litres} onChange={e => updateEquipEntry(i, 'fuel_litres', e.target.value)} /></div>
                    <div className="form-group"><label>Operator</label><input type="text" value={entry.operator_name} onChange={e => updateEquipEntry(i, 'operator_name', e.target.value)} /></div>
                    <div className="form-group"><label>Location (Ch.)</label><input type="text" value={entry.location_chainage} onChange={e => updateEquipEntry(i, 'location_chainage', e.target.value)} /></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addEquipEntry}>+ Add Equipment</button>
            </div>
          )}
        </div>

        {/* ===== STRUCTURES ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.structures ? 'open' : ''}`} onClick={() => toggleSection('structures')}>
            <span>🌉 Structures Progress{sectionCount(structEntries)}</span>
            <span className="toggle-arrow">{openSections.structures ? '▼' : '▶'}</span>
          </button>
          {openSections.structures && (
            <div className="section-body">
              <p className="section-hint">Record progress on culverts, bridges, gabions, and other structures.</p>
              {structEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Structure #{i + 1}</span>
                    <button type="button" className="btn-remove" onClick={() => removeStructEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group flex-2">
                      <label>Structure</label>
                      {projectStructures.length > 0 ? (
                        <select value={entry.structure_id} onChange={e => updateStructEntry(i, 'structure_id', e.target.value)}>
                          <option value="">Select structure...</option>
                          {projectStructures.map(s => <option key={s.id} value={s.id}>{s.structure_ref} - {s.structure_type} @ Ch {s.chainage}</option>)}
                        </select>
                      ) : (
                        <input type="text" value={entry.structure_name} onChange={e => updateStructEntry(i, 'structure_name', e.target.value)} placeholder="e.g. BC-001 Box Culvert @ 2+350" />
                      )}
                    </div>
                    <div className="form-group">
                      <label>Stage</label>
                      <select value={entry.stage} onChange={e => updateStructEntry(i, 'stage', e.target.value)} required>
                        <option value="">Select stage...</option>
                        {STRUCTURE_STAGES.map(s => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group flex-2"><label>Work Description</label><input type="text" value={entry.description} onChange={e => updateStructEntry(i, 'description', e.target.value)} placeholder="What was done..." /></div>
                    <div className="form-group"><label>Crew Size</label><input type="number" value={entry.crew_size} onChange={e => updateStructEntry(i, 'crew_size', e.target.value)} /></div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Concrete (m³)</label><input type="number" step="0.1" value={entry.concrete_volume} onChange={e => updateStructEntry(i, 'concrete_volume', e.target.value)} /></div>
                    <div className="form-group"><label>Concrete Grade</label><input type="text" value={entry.concrete_grade} onChange={e => updateStructEntry(i, 'concrete_grade', e.target.value)} placeholder="C25/30" /></div>
                    <div className="form-group"><label>Rebar (Tonnes)</label><input type="number" step="0.01" value={entry.rebar_tonnes} onChange={e => updateStructEntry(i, 'rebar_tonnes', e.target.value)} /></div>
                    <div className="form-group"><label>Remarks</label><input type="text" value={entry.remarks} onChange={e => updateStructEntry(i, 'remarks', e.target.value)} /></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addStructEntry}>+ Add Structure Progress</button>
            </div>
          )}
        </div>

        {/* ===== PAVEMENT LAYERS ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.pavement ? 'open' : ''}`} onClick={() => toggleSection('pavement')}>
            <span>🛣️ Pavement Layer Work{sectionCount(pavementEntries)}</span>
            <span className="toggle-arrow">{openSections.pavement ? '▼' : '▶'}</span>
          </button>
          {openSections.pavement && (
            <div className="section-body">
              <p className="section-hint">Record pavement layer placement — subgrade through wearing course.</p>
              {pavementEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Layer #{i + 1}</span>
                    <button type="button" className="btn-remove" onClick={() => removePavementEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Layer Type</label>
                      <select value={entry.layer_type} onChange={e => updatePavementEntry(i, 'layer_type', e.target.value)} required>
                        <option value="">Select...</option>
                        {LAYER_TYPES.map(l => <option key={l}>{l}</option>)}
                      </select>
                    </div>
                    <div className="form-group"><label>Ch. From</label><input type="number" step="0.001" value={entry.chainage_from} onChange={e => updatePavementEntry(i, 'chainage_from', e.target.value)} /></div>
                    <div className="form-group"><label>Ch. To</label><input type="number" step="0.001" value={entry.chainage_to} onChange={e => updatePavementEntry(i, 'chainage_to', e.target.value)} /></div>
                    <div className="form-group"><label>Side</label>
                      <select value={entry.side} onChange={e => updatePavementEntry(i, 'side', e.target.value)}>
                        <option>Full</option><option>LHS</option><option>RHS</option><option>CL</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Width (m)</label><input type="number" step="0.1" value={entry.width_m} onChange={e => updatePavementEntry(i, 'width_m', e.target.value)} /></div>
                    <div className="form-group"><label>Thickness (mm)</label><input type="number" value={entry.thickness_mm} onChange={e => updatePavementEntry(i, 'thickness_mm', e.target.value)} /></div>
                    <div className="form-group"><label>Material Source</label><input type="text" value={entry.material_source} onChange={e => updatePavementEntry(i, 'material_source', e.target.value)} placeholder="Quarry name" /></div>
                    <div className="form-group"><label>Material Type</label><input type="text" value={entry.material_type} onChange={e => updatePavementEntry(i, 'material_type', e.target.value)} placeholder="GCS, AC 14" /></div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Compaction</label>
                      <select value={entry.compaction_status} onChange={e => updatePavementEntry(i, 'compaction_status', e.target.value)}>
                        <option value="">Select...</option><option>Not Started</option><option>In Progress</option><option>Completed - Pending Test</option><option>Tested - Pass</option><option>Tested - Fail</option>
                      </select>
                    </div>
                    <div className="form-group flex-2"><label>Remarks</label><input type="text" value={entry.remarks} onChange={e => updatePavementEntry(i, 'remarks', e.target.value)} /></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addPavementEntry}>+ Add Pavement Layer</button>
            </div>
          )}
        </div>

        {/* ===== QUALITY TESTS ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.quality ? 'open' : ''}`} onClick={() => toggleSection('quality')}>
            <span>🧪 Quality Tests{sectionCount(testEntries)}</span>
            <span className="toggle-arrow">{openSections.quality ? '▼' : '▶'}</span>
          </button>
          {openSections.quality && (
            <div className="section-body">
              <p className="section-hint">Record test results. Kenya RDM spec limits auto-fill when you select test type and layer. Pass/Fail auto-assesses.</p>
              {testEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Test #{i + 1} {entry.assessment && <span className={`badge badge-${entry.assessment.toLowerCase()}`}>{entry.assessment}</span>}</span>
                    <button type="button" className="btn-remove" onClick={() => removeTestEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Test Type</label>
                      <select value={entry.test_type} onChange={e => updateTestEntry(i, 'test_type', e.target.value)} required>
                        <option value="">Select...</option>
                        {TEST_TYPES.map(t => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Layer</label>
                      <select value={entry.layer_type} onChange={e => updateTestEntry(i, 'layer_type', e.target.value)}>
                        <option value="">Select...</option>
                        {LAYER_TYPES.map(l => <option key={l}>{l}</option>)}
                      </select>
                    </div>
                    <div className="form-group"><label>Chainage</label><input type="text" value={entry.chainage} onChange={e => updateTestEntry(i, 'chainage', e.target.value)} placeholder="2+350" /></div>
                    <div className="form-group"><label>Side</label>
                      <select value={entry.side} onChange={e => updateTestEntry(i, 'side', e.target.value)}>
                        <option value="">-</option><option>LHS</option><option>RHS</option><option>CL</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Sample Ref</label><input type="text" value={entry.sample_ref} onChange={e => updateTestEntry(i, 'sample_ref', e.target.value)} /></div>
                    <div className="form-group"><label>Result</label><input type="number" step="0.01" value={entry.result_value} onChange={e => updateTestEntry(i, 'result_value', e.target.value)} /></div>
                    <div className="form-group"><label>Unit</label><input type="text" value={entry.result_unit} readOnly className="readonly" /></div>
                    <div className="form-group"><label>Spec Min</label><input type="text" value={entry.spec_min ?? '-'} readOnly className="readonly" /></div>
                    <div className="form-group"><label>Spec Max</label><input type="text" value={entry.spec_max ?? '-'} readOnly className="readonly" /></div>
                  </div>
                  <div className="form-row">
                    <div className="form-group"><label>Tested By</label><input type="text" value={entry.tested_by} onChange={e => updateTestEntry(i, 'tested_by', e.target.value)} /></div>
                    <div className="form-group"><label>Lab Ref</label><input type="text" value={entry.lab_ref} onChange={e => updateTestEntry(i, 'lab_ref', e.target.value)} /></div>
                    <div className="form-group flex-2"><label>Remarks</label><input type="text" value={entry.remarks} onChange={e => updateTestEntry(i, 'remarks', e.target.value)} /></div>
                  </div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addTestEntry}>+ Add Quality Test</button>
            </div>
          )}
        </div>

        {/* ===== SITE ISSUES ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.issues ? 'open' : ''}`} onClick={() => toggleSection('issues')}>
            <span>⚠️ Site Issues{sectionCount(issueEntries)}</span>
            <span className="toggle-arrow">{openSections.issues ? '▼' : '▶'}</span>
          </button>
          {openSections.issues && (
            <div className="section-body">
              <p className="section-hint">Log problems, observations, or concerns. Mark as emergency for immediate notification.</p>
              {issueEntries.map((entry, i) => (
                <div key={i} className="entry-card">
                  <div className="entry-header">
                    <span>Issue #{i + 1}</span>
                    <button type="button" className="btn-remove" onClick={() => removeIssueEntry(i)}>✕</button>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Category</label>
                      <select value={entry.category} onChange={e => updateIssueEntry(i, 'category', e.target.value)}>
                        {ISSUE_CATEGORIES.map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Severity</label>
                      <select value={entry.severity} onChange={e => updateIssueEntry(i, 'severity', e.target.value)}>
                        <option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
                      </select>
                    </div>
                    <div className="form-group"><label>Chainage</label><input type="text" value={entry.chainage} onChange={e => updateIssueEntry(i, 'chainage', e.target.value)} /></div>
                    <div className="form-group" style={{ display: 'flex', alignItems: 'end', gap: 8 }}>
                      <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                        <input type="checkbox" checked={entry.is_emergency} onChange={e => updateIssueEntry(i, 'is_emergency', e.target.checked)} />
                        🚨 Emergency
                      </label>
                    </div>
                  </div>
                  <div className="form-group"><label>Description *</label><textarea value={entry.description} onChange={e => updateIssueEntry(i, 'description', e.target.value)} rows={2} required placeholder="Describe the issue..." /></div>
                  <div className="form-group"><label>Action Required</label><input type="text" value={entry.action_required} onChange={e => updateIssueEntry(i, 'action_required', e.target.value)} placeholder="What needs to be done..." /></div>
                </div>
              ))}
              <button type="button" className="btn btn-add" onClick={addIssueEntry}>+ Add Site Issue</button>
            </div>
          )}
        </div>

        {/* ===== LABOUR & MATERIALS ===== */}
        <div className="report-section">
          <button type="button" className={`section-toggle ${openSections.labour ? 'open' : ''}`} onClick={() => toggleSection('labour')}>
            <span>👷 Labour & Materials</span>
            <span className="toggle-arrow">{openSections.labour ? '▼' : '▶'}</span>
          </button>
          {openSections.labour && (
            <div className="section-body">
              <h4 style={{ marginBottom: 12 }}>Workforce Summary</h4>
              <div className="form-row">
                <div className="form-group"><label>Skilled Workers</label><input type="number" value={labourSummary.skilled} onChange={e => setLabourSummary(p => ({ ...p, skilled: e.target.value }))} /></div>
                <div className="form-group"><label>Unskilled Workers</label><input type="number" value={labourSummary.unskilled} onChange={e => setLabourSummary(p => ({ ...p, unskilled: e.target.value }))} /></div>
                <div className="form-group"><label>Supervisors</label><input type="number" value={labourSummary.supervisors} onChange={e => setLabourSummary(p => ({ ...p, supervisors: e.target.value }))} /></div>
                <div className="form-group"><label>Total on Site</label><input type="number" value={labourSummary.total} onChange={e => setLabourSummary(p => ({ ...p, total: e.target.value }))} /></div>
              </div>
              <h4 style={{ marginTop: 16, marginBottom: 12 }}>Materials Received / Delivered</h4>
              <div className="form-group">
                <textarea value={materialsReceived} onChange={e => setMaterialsReceived(e.target.value)} rows={3} placeholder="e.g. 3 trips GCS from Mlolongo Quarry (approx 90m³)&#10;2 tonnes Y12 rebar delivered..." />
              </div>
            </div>
          )}
        </div>

        {/* ===== SUBMIT ===== */}
        <div className="submit-bar">
          <div className="submit-summary">
            {worksEntries.length > 0 && <span className="sum-tag">⛏️ {worksEntries.length}</span>}
            {equipEntries.length > 0 && <span className="sum-tag">🚜 {equipEntries.length}</span>}
            {structEntries.length > 0 && <span className="sum-tag">🌉 {structEntries.length}</span>}
            {pavementEntries.length > 0 && <span className="sum-tag">🛣️ {pavementEntries.length}</span>}
            {testEntries.length > 0 && <span className="sum-tag">🧪 {testEntries.length}</span>}
            {issueEntries.length > 0 && <span className="sum-tag">⚠️ {issueEntries.length}</span>}
          </div>
          <button type="submit" className="btn btn-primary btn-submit" disabled={saving}>
            {saving ? '⏳ Submitting & Syncing All Modules...' : '✅ Submit Report & Sync'}
          </button>
        </div>
      </form>
    </div>
  );
}
