import React, { useState } from 'react';
import { signUp, signIn, resetPassword } from '../lib/supabase';

export default function AuthPage() {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [title, setTitle] = useState('');
  const [profession, setProfession] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setMessage(''); setLoading(true);
    try {
      if (mode === 'login') {
        await signIn(email, password);
      } else if (mode === 'register') {
        await signUp(email, password, fullName, phone, title, profession);
        setMessage('Registration successful! Please check your email to verify, then wait for admin approval.');
        setMode('login');
      } else if (mode === 'forgot') {
        await resetPassword(email);
        setMessage('Password reset link sent to your email.');
        setMode('login');
      }
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <h1>🚧 RoadSite Reports</h1>
          <p>Road Construction Field Reporting & Quality Management</p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}

        <form onSubmit={handleSubmit}>
          {mode === 'register' && (
            <>
              <div className="form-group">
                <label>Full Name *</label>
                <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} required placeholder="e.g. Eng. Collins Olaki" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Title</label>
                  <select value={title} onChange={e => setTitle(e.target.value)}>
                    <option value="">Select</option>
                    <option>Mr.</option><option>Mrs.</option><option>Ms.</option>
                    <option>Dr.</option><option>Eng.</option><option>Prof.</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Profession</label>
                  <select value={profession} onChange={e => setProfession(e.target.value)}>
                    <option value="">Select</option>
                    <option>Civil Engineer</option><option>Structural Engineer</option>
                    <option>Materials Engineer</option><option>Surveyor</option>
                    <option>Quantity Surveyor</option><option>Geotechnical Engineer</option>
                    <option>Environmental Specialist</option><option>Safety Officer</option>
                    <option>Site Inspector</option><option>Lab Technician</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+254 7XX XXX XXX" />
              </div>
            </>
          )}

          <div className="form-group">
            <label>Email *</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="your@email.com" />
          </div>

          {mode !== 'forgot' && (
            <div className="form-group">
              <label>Password *</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} placeholder="Min 6 characters" />
            </div>
          )}

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : mode === 'register' ? 'Create Account' : 'Send Reset Link'}
          </button>
        </form>

        <div className="auth-links">
          {mode === 'login' && (
            <>
              <button onClick={() => { setMode('register'); setError(''); }} className="link-btn">Create an account</button>
              <button onClick={() => { setMode('forgot'); setError(''); }} className="link-btn">Forgot password?</button>
            </>
          )}
          {mode !== 'login' && (
            <button onClick={() => { setMode('login'); setError(''); }} className="link-btn">← Back to login</button>
          )}
        </div>
      </div>
    </div>
  );
}
