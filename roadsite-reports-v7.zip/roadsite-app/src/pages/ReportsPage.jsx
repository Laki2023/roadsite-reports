import React, { useState, useEffect } from 'react';
import { getProjects, getReports, getReportById } from '../lib/supabase';

export default function ReportsPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [reports, setReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { getProjects().then(setProjects).catch(console.error).finally(() => setLoading(false)); }, []);

  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      getReports(selectedProject).then(setReports).catch(console.error).finally(() => setLoading(false));
    } else {
      getReports().then(setReports).catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  async function viewReport(id) {
    try {
      const r = await getReportById(id);
      setSelectedReport(r);
    } catch (err) { console.error(err); }
  }

  if (selectedReport) {
    const r = selectedReport;
    return (
      <div className="page-container">
        <button className="btn btn-secondary" onClick={() => setSelectedReport(null)}>← Back to Reports</button>
        <div className="report-detail">
          <h2>Daily Report — {r.report_date}</h2>
          <div className="detail-grid">
            <div><strong>Weather (AM):</strong> {r.weather_morning || '-'}</div>
            <div><strong>Weather (PM):</strong> {r.weather_afternoon || '-'}</div>
            <div><strong>Temp:</strong> {r.temperature_low || '-'}°C – {r.temperature_high || '-'}°C</div>
            <div><strong>Shift:</strong> {r.shift_type || '-'}</div>
          </div>
          {r.general_remarks && <div className="detail-section"><h4>General Remarks</h4><p>{r.general_remarks}</p></div>}
          {r.visitors && <div className="detail-section"><h4>Visitors</h4><p>{r.visitors}</p></div>}
          {r.safety_incidents && <div className="detail-section"><h4>Safety Incidents</h4><p>{r.safety_incidents}</p></div>}
          {r.instructions_received && <div className="detail-section"><h4>Instructions</h4><p>{r.instructions_received}</p></div>}
          {r.labour_summary && <div className="detail-section"><h4>Labour</h4><pre>{JSON.stringify(r.labour_summary, null, 2)}</pre></div>}
          {r.materials_received && <div className="detail-section"><h4>Materials Received</h4><p>{r.materials_received}</p></div>}
          <p className="detail-note">Engineering module data (works, equipment, structures, tests, etc.) synced from this report is viewable in the respective module pages.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>📋 Submitted Reports</h2>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">All Projects</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>
      {loading ? <div className="loading"><div className="spinner" /></div> : reports.length === 0 ? (
        <p className="empty">No reports found.</p>
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Date</th><th>Submitted By</th><th>Weather</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {reports.map(r => (
                <tr key={r.id}>
                  <td><strong>{r.report_date}</strong></td>
                  <td>{r.profiles?.full_name || '-'}</td>
                  <td>{r.weather_morning || '-'} / {r.weather_afternoon || '-'}</td>
                  <td><span className={`status-badge status-${r.status}`}>{r.status}</span></td>
                  <td><button className="btn btn-sm" onClick={() => viewReport(r.id)}>View</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
