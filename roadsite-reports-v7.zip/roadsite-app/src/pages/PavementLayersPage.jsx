import React, { useState, useEffect } from 'react';
import { getProjects, getPavementLayers } from '../lib/supabase';

const LAYER_ORDER = ['Subgrade', 'Improved Subgrade', 'Sub-base', 'Base', 'Prime Coat', 'Tack Coat', 'Binder Course', 'Wearing Course', 'Seal'];

export default function PavementLayersPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [layers, setLayers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);
  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      getPavementLayers(selectedProject).then(setLayers).catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  // Group by layer type for summary
  const layerSummary = LAYER_ORDER.map(lt => {
    const entries = layers.filter(l => l.layer_type === lt);
    const totalLength = entries.reduce((s, l) => {
      const from = parseFloat(l.chainage_from) || 0;
      const to = parseFloat(l.chainage_to) || 0;
      return s + Math.abs(to - from);
    }, 0);
    return { type: lt, count: entries.length, totalLength: totalLength.toFixed(3) };
  }).filter(l => l.count > 0);

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>🛣️ Pavement Layers</h2>
        <p className="page-subtitle">Read-only — layer work data from daily site reports</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view pavement layers.</p>
      ) : layers.length === 0 ? (
        <p className="empty">No pavement layer data yet. Data will appear here as daily reports are submitted.</p>
      ) : (
        <>
          {/* Layer Stack Visualization */}
          <div className="layer-stack">
            <h3>Layer Summary</h3>
            <div className="stack-visual">
              {[...layerSummary].reverse().map((l, i) => (
                <div key={l.type} className={`stack-layer layer-${i}`}>
                  <span className="layer-name">{l.type}</span>
                  <span className="layer-info">{l.count} entries | {l.totalLength} km</span>
                </div>
              ))}
            </div>
          </div>

          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Date</th><th>Layer</th><th>Ch. From</th><th>Ch. To</th><th>Side</th><th>Width (m)</th><th>Thick (mm)</th><th>Material</th><th>Compaction</th></tr></thead>
              <tbody>
                {layers.map(l => (
                  <tr key={l.id}>
                    <td>{l.work_date}</td>
                    <td><strong>{l.layer_type}</strong></td>
                    <td>{l.chainage_from}</td>
                    <td>{l.chainage_to}</td>
                    <td>{l.side}</td>
                    <td>{l.width_m || '-'}</td>
                    <td>{l.thickness_mm || '-'}</td>
                    <td>{l.material_type || '-'}</td>
                    <td>{l.compaction_status || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
