import React, { useState, useEffect } from 'react';
import { getAllProfiles, updateProfileRole } from '../lib/supabase';

const ROLES = ['pending', 'inspector', 're', 'engineer', 'pm', 'admin', 'super_admin'];

export default function AdminPanel({ profile }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { getAllProfiles().then(setUsers).catch(console.error).finally(() => setLoading(false)); }, []);

  async function handleRoleChange(userId, newRole) {
    try {
      await updateProfileRole(userId, newRole);
      const u = await getAllProfiles();
      setUsers(u);
    } catch (err) { alert(err.message); }
  }

  const pending = users.filter(u => u.role === 'pending');
  const active = users.filter(u => u.role !== 'pending');

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>⚙️ Admin Panel</h2>
      </div>

      {pending.length > 0 && (
        <div className="dash-card" style={{ marginBottom: 24, borderLeft: '4px solid #f59e0b' }}>
          <h3>⏳ Pending Approvals ({pending.length})</h3>
          {pending.map(u => (
            <div key={u.id} className="user-row">
              <div>
                <strong>{u.full_name}</strong>
                <span className="user-email">{u.email}</span>
                {u.profession && <span className="user-profession">{u.profession}</span>}
              </div>
              <div className="user-actions">
                <button className="btn btn-sm btn-success" onClick={() => handleRoleChange(u.id, 'inspector')}>Approve as Inspector</button>
                <button className="btn btn-sm" onClick={() => handleRoleChange(u.id, 're')}>Approve as RE</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {loading ? <div className="loading"><div className="spinner" /></div> : (
        <div className="dash-card">
          <h3>Active Users ({active.length})</h3>
          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Name</th><th>Email</th><th>Title</th><th>Role</th><th>Action</th></tr></thead>
              <tbody>
                {active.map(u => (
                  <tr key={u.id}>
                    <td><strong>{u.full_name}</strong></td>
                    <td>{u.email}</td>
                    <td>{u.title || ''} {u.profession || ''}</td>
                    <td>
                      <select value={u.role} onChange={e => handleRoleChange(u.id, e.target.value)} className="role-select">
                        {ROLES.filter(r => r !== 'pending').map(r => <option key={r} value={r}>{r.toUpperCase()}</option>)}
                      </select>
                    </td>
                    <td><span className={`status-badge status-${u.role}`}>{u.role.toUpperCase()}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
