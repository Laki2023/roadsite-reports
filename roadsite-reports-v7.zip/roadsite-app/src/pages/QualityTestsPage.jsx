import React, { useState, useEffect } from 'react';
import { getProjects, getQualityTests } from '../lib/supabase';

export default function QualityTestsPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);
  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      getQualityTests(selectedProject).then(setTests).catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  const totalTests = tests.length;
  const passed = tests.filter(t => t.assessment === 'Pass').length;
  const failed = tests.filter(t => t.assessment === 'Fail').length;
  const marginal = tests.filter(t => t.assessment === 'Marginal').length;
  const passRate = totalTests > 0 ? Math.round(passed / totalTests * 100) : 0;

  // Group by test type
  const byType = {};
  tests.forEach(t => {
    if (!byType[t.test_type]) byType[t.test_type] = { pass: 0, fail: 0, marginal: 0, total: 0 };
    byType[t.test_type].total++;
    if (t.assessment === 'Pass') byType[t.test_type].pass++;
    else if (t.assessment === 'Fail') byType[t.test_type].fail++;
    else if (t.assessment === 'Marginal') byType[t.test_type].marginal++;
  });

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>🧪 Quality Tests</h2>
        <p className="page-subtitle">Read-only — test results auto-assessed against Kenya RDM specs</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view quality tests.</p>
      ) : tests.length === 0 ? (
        <p className="empty">No quality test data yet.</p>
      ) : (
        <>
          <div className="stats-grid" style={{ marginBottom: 20 }}>
            <div className="stat-card"><div className="stat-value">{totalTests}</div><div className="stat-label">Total Tests</div></div>
            <div className="stat-card" style={{ borderLeft: '4px solid #22c55e' }}><div className="stat-value">{passRate}%</div><div className="stat-label">Pass Rate</div></div>
            <div className="stat-card"><div className="stat-value" style={{ color: '#22c55e' }}>{passed}</div><div className="stat-label">Passed</div></div>
            <div className="stat-card"><div className="stat-value" style={{ color: '#ef4444' }}>{failed}</div><div className="stat-label">Failed</div></div>
          </div>

          {Object.keys(byType).length > 0 && (
            <div className="dash-card" style={{ marginBottom: 20 }}>
              <h3>Pass Rate by Test Type</h3>
              <div className="test-type-grid">
                {Object.entries(byType).map(([type, data]) => (
                  <div key={type} className="test-type-bar">
                    <span className="tt-label">{type}</span>
                    <div className="tt-bar-bg">
                      <div className="tt-bar-fill" style={{ width: `${data.total > 0 ? (data.pass / data.total * 100) : 0}%` }} />
                    </div>
                    <span className="tt-pct">{data.total > 0 ? Math.round(data.pass / data.total * 100) : 0}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Date</th><th>Test</th><th>Layer</th><th>Ch.</th><th>Result</th><th>Spec</th><th>Assessment</th><th>Lab Ref</th></tr></thead>
              <tbody>
                {tests.map(t => (
                  <tr key={t.id}>
                    <td>{t.test_date}</td>
                    <td><strong>{t.test_type}</strong></td>
                    <td>{t.layer_type || '-'}</td>
                    <td>{t.chainage || '-'}</td>
                    <td>{t.result_value} {t.result_unit}</td>
                    <td>{t.spec_min != null || t.spec_max != null ? `${t.spec_min ?? '-'} – ${t.spec_max ?? '-'}` : '-'}</td>
                    <td><span className={`badge badge-${(t.assessment || '').toLowerCase()}`}>{t.assessment || '-'}</span></td>
                    <td>{t.lab_ref || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
