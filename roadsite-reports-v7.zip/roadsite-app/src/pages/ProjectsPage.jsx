import React, { useState, useEffect } from 'react';
import { getProjects, createProject } from '../lib/supabase';

const FIDIC_EDITIONS = ['FIDIC 1987 Red Book', 'FIDIC 1999 Red Book', 'FIDIC 2017 Red Book', 'FIDIC Pink Book (MDB)', 'FIDIC Yellow Book', 'Other'];
const CATEGORIES = ['Construction', 'Rehabilitation', 'Maintenance'];
const ROAD_CLASSES = ['Class A', 'Class B', 'Class C', 'Class D', 'Class E', 'Special Purpose', 'Urban'];

export default function ProjectsPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    name: '', contract_no: '', contractor: '', consultant: '', category: 'Construction',
    fidic_edition: 'FIDIC 1999 Red Book', contract_sum: '', county: '', road_class: '',
    chainage_start: '', chainage_end: '', start_date: '', end_date: '', status: 'Active'
  });

  useEffect(() => { getProjects().then(setProjects).catch(console.error).finally(() => setLoading(false)); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    try {
      await createProject({
        ...form,
        contract_sum: form.contract_sum ? parseFloat(form.contract_sum) : null,
        chainage_start: form.chainage_start ? parseFloat(form.chainage_start) : null,
        chainage_end: form.chainage_end ? parseFloat(form.chainage_end) : null
      });
      const p = await getProjects();
      setProjects(p);
      setShowForm(false);
    } catch (err) { alert(err.message); }
  }

  const isAdmin = ['admin', 'super_admin', 'pm', 'engineer'].includes(profile.role);

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>🏗️ Projects</h2>
        {isAdmin && <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>{showForm ? 'Cancel' : '+ New Project'}</button>}
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="entry-card" style={{ marginBottom: 24 }}>
          <h3>New Project</h3>
          <div className="form-group"><label>Project Name *</label><input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} required placeholder="e.g. Nairobi-Thika Highway Dualling" /></div>
          <div className="form-row">
            <div className="form-group"><label>Contract No.</label><input value={form.contract_no} onChange={e => setForm(p => ({ ...p, contract_no: e.target.value }))} placeholder="KeNHA/RD/..." /></div>
            <div className="form-group"><label>Category</label>
              <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select>
            </div>
            <div className="form-group"><label>FIDIC Edition</label>
              <select value={form.fidic_edition} onChange={e => setForm(p => ({ ...p, fidic_edition: e.target.value }))}>{FIDIC_EDITIONS.map(f => <option key={f}>{f}</option>)}</select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Contractor</label><input value={form.contractor} onChange={e => setForm(p => ({ ...p, contractor: e.target.value }))} /></div>
            <div className="form-group"><label>Consultant</label><input value={form.consultant} onChange={e => setForm(p => ({ ...p, consultant: e.target.value }))} /></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Contract Sum (KES)</label><input type="number" value={form.contract_sum} onChange={e => setForm(p => ({ ...p, contract_sum: e.target.value }))} /></div>
            <div className="form-group"><label>County</label><input value={form.county} onChange={e => setForm(p => ({ ...p, county: e.target.value }))} /></div>
            <div className="form-group"><label>Road Class</label>
              <select value={form.road_class} onChange={e => setForm(p => ({ ...p, road_class: e.target.value }))}><option value="">Select...</option>{ROAD_CLASSES.map(r => <option key={r}>{r}</option>)}</select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Chainage Start</label><input type="number" step="0.001" value={form.chainage_start} onChange={e => setForm(p => ({ ...p, chainage_start: e.target.value }))} /></div>
            <div className="form-group"><label>Chainage End</label><input type="number" step="0.001" value={form.chainage_end} onChange={e => setForm(p => ({ ...p, chainage_end: e.target.value }))} /></div>
            <div className="form-group"><label>Start Date</label><input type="date" value={form.start_date} onChange={e => setForm(p => ({ ...p, start_date: e.target.value }))} /></div>
            <div className="form-group"><label>End Date</label><input type="date" value={form.end_date} onChange={e => setForm(p => ({ ...p, end_date: e.target.value }))} /></div>
          </div>
          <button type="submit" className="btn btn-primary">Create Project</button>
        </form>
      )}

      {loading ? <div className="loading"><div className="spinner" /></div> : projects.length === 0 ? (
        <p className="empty">No projects yet.</p>
      ) : (
        <div className="project-cards">
          {projects.map(p => (
            <div key={p.id} className="project-card-full">
              <h3>{p.name}</h3>
              <div className="project-meta-grid">
                <div><strong>Contract:</strong> {p.contract_no || '-'}</div>
                <div><strong>Category:</strong> {p.category || '-'}</div>
                <div><strong>FIDIC:</strong> {p.fidic_edition || '-'}</div>
                <div><strong>Contractor:</strong> {p.contractor || '-'}</div>
                <div><strong>Consultant:</strong> {p.consultant || '-'}</div>
                <div><strong>County:</strong> {p.county || '-'}</div>
                <div><strong>Chainage:</strong> {p.chainage_start || '?'} – {p.chainage_end || '?'}</div>
                <div><strong>Contract Sum:</strong> {p.contract_sum ? `KES ${Number(p.contract_sum).toLocaleString()}` : '-'}</div>
                <div><strong>Status:</strong> <span className={`status-badge status-${(p.status || 'active').toLowerCase()}`}>{p.status || 'Active'}</span></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
