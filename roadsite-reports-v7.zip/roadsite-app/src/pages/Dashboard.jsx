import React, { useState, useEffect } from 'react';
import { getProjects, getReports } from '../lib/supabase';

export default function Dashboard({ profile, setPage, alerts }) {
  const [projects, setProjects] = useState([]);
  const [recentReports, setRecentReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const p = await getProjects();
        setProjects(p);
        const r = await getReports();
        setRecentReports(r.slice(0, 10));
      } catch (err) { console.error(err); }
      setLoading(false);
    }
    load();
  }, []);

  if (loading) return <div className="loading"><div className="spinner" /></div>;

  const activeProjects = projects.filter(p => p.status === 'Active' || !p.status);

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>📊 Dashboard</h2>
        <p className="page-subtitle">Welcome back, {profile.full_name}</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card" onClick={() => setPage('projects')}>
          <div className="stat-value">{activeProjects.length}</div>
          <div className="stat-label">Active Projects</div>
        </div>
        <div className="stat-card" onClick={() => setPage('reports')}>
          <div className="stat-value">{recentReports.length}</div>
          <div className="stat-label">Recent Reports</div>
        </div>
        <div className="stat-card accent" onClick={() => setPage('issues')}>
          <div className="stat-value">{alerts.length}</div>
          <div className="stat-label">Open Alerts</div>
        </div>
        <div className="stat-card action" onClick={() => setPage('submit-report')}>
          <div className="stat-value">📝</div>
          <div className="stat-label">Submit Report</div>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="dash-card">
          <h3>Recent Reports</h3>
          {recentReports.length === 0 ? <p className="empty">No reports yet. Submit your first daily report!</p> : (
            <div className="report-list">
              {recentReports.map(r => (
                <div key={r.id} className="report-item">
                  <div>
                    <strong>{r.report_date}</strong>
                    <span className="report-author">{r.profiles?.full_name}</span>
                  </div>
                  <span className={`status-badge status-${r.status}`}>{r.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="dash-card">
          <h3>Active Projects</h3>
          {activeProjects.length === 0 ? <p className="empty">No active projects.</p> : (
            <div className="project-list">
              {activeProjects.map(p => (
                <div key={p.id} className="project-item">
                  <strong>{p.name}</strong>
                  <span className="project-meta">{p.contractor || 'No contractor'} | {p.contract_no || ''}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="quick-nav">
        <h3>Road Engineering Modules</h3>
        <p style={{ color: '#666', marginBottom: 16 }}>These modules are read-only dashboards populated automatically from daily report submissions.</p>
        <div className="nav-grid">
          {[
            { id: 'works', icon: '⛏️', label: 'Works Activities', desc: 'Activity progress matrix' },
            { id: 'equipment', icon: '🚜', label: 'Equipment', desc: 'Fleet status & utilization' },
            { id: 'structures', icon: '🌉', label: 'Structures', desc: 'Culverts, bridges, gabions' },
            { id: 'pavement', icon: '🛣️', label: 'Pavement Layers', desc: 'Layer-by-layer tracking' },
            { id: 'quality', icon: '🧪', label: 'Quality Tests', desc: 'Test results & pass rates' },
            { id: 'issues', icon: '⚠️', label: 'Site Issues', desc: 'Problems & alerts' },
          ].map(m => (
            <button key={m.id} className="nav-tile" onClick={() => setPage(m.id)}>
              <span className="tile-icon">{m.icon}</span>
              <span className="tile-label">{m.label}</span>
              <span className="tile-desc">{m.desc}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
