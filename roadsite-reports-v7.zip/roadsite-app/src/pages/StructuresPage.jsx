import React, { useState, useEffect } from 'react';
import { getProjects, getStructures, getStructureProgress, addStructure } from '../lib/supabase';

const STRUCTURE_TYPES = ['Box Culvert', 'Pipe Culvert', 'Slab Culvert', 'Bridge', 'Footbridge', 'Gabion Wall', 'Gabion Mattress', 'Retaining Wall (Masonry)', 'Retaining Wall (RC)', 'Drift/Causeway', 'Headwall', 'Wingwall', 'Apron', 'Scour Protection', 'River Training', 'Guard Rail at Structure'];

export default function StructuresPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [structures, setStructures] = useState([]);
  const [progress, setProgress] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newStr, setNewStr] = useState({ structure_type: '', structure_ref: '', chainage: '', side: 'CL', span_m: '', no_of_cells: 1, concrete_grade: '' });
  const isAdmin = ['admin', 'super_admin', 'pm', 'engineer'].includes(profile.role);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);
  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      Promise.all([getStructures(selectedProject), getStructureProgress(selectedProject)])
        .then(([s, p]) => { setStructures(s); setProgress(p); })
        .catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  async function handleAdd() {
    try {
      await addStructure({ ...newStr, project_id: selectedProject, chainage: parseFloat(newStr.chainage) || 0 });
      const s = await getStructures(selectedProject);
      setStructures(s);
      setShowAdd(false);
    } catch (err) { alert(err.message); }
  }

  const structWithProgress = structures.map(s => {
    const entries = progress.filter(p => p.structure_id === s.id);
    const stages = [...new Set(entries.map(e => e.stage))];
    const lastEntry = entries[0];
    const totalConcrete = entries.reduce((sum, e) => sum + (parseFloat(e.concrete_volume) || 0), 0);
    return { ...s, stagesCompleted: stages.length, lastStage: lastEntry?.stage, lastDate: lastEntry?.work_date, totalConcrete, entryCount: entries.length };
  });

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>🌉 Structures</h2>
        <p className="page-subtitle">Read-only — progress data from daily site reports</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {isAdmin && selectedProject && <button className="btn btn-primary" onClick={() => setShowAdd(!showAdd)}>+ Add Structure</button>}
      </div>

      {showAdd && (
        <div className="entry-card" style={{ marginBottom: 20 }}>
          <h4>Register New Structure</h4>
          <div className="form-row">
            <div className="form-group"><label>Type</label>
              <select value={newStr.structure_type} onChange={e => setNewStr(p => ({ ...p, structure_type: e.target.value }))}>
                <option value="">Select...</option>
                {STRUCTURE_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="form-group"><label>Reference</label><input value={newStr.structure_ref} onChange={e => setNewStr(p => ({ ...p, structure_ref: e.target.value }))} placeholder="BC-001" /></div>
            <div className="form-group"><label>Chainage</label><input type="number" step="0.001" value={newStr.chainage} onChange={e => setNewStr(p => ({ ...p, chainage: e.target.value }))} /></div>
            <div className="form-group"><label>Side</label>
              <select value={newStr.side} onChange={e => setNewStr(p => ({ ...p, side: e.target.value }))}><option>CL</option><option>LHS</option><option>RHS</option></select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Span (m)</label><input type="number" step="0.1" value={newStr.span_m} onChange={e => setNewStr(p => ({ ...p, span_m: e.target.value }))} /></div>
            <div className="form-group"><label>No. of Cells</label><input type="number" value={newStr.no_of_cells} onChange={e => setNewStr(p => ({ ...p, no_of_cells: e.target.value }))} /></div>
            <div className="form-group"><label>Concrete Grade</label><input value={newStr.concrete_grade} onChange={e => setNewStr(p => ({ ...p, concrete_grade: e.target.value }))} placeholder="C25/30" /></div>
          </div>
          <button className="btn btn-primary" onClick={handleAdd}>Save Structure</button>
        </div>
      )}

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view structures.</p>
      ) : structures.length === 0 ? (
        <p className="empty">No structures registered. {isAdmin ? 'Add structures using the button above.' : ''}</p>
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Ref</th><th>Type</th><th>Chainage</th><th>Side</th><th>Stages Done</th><th>Last Stage</th><th>Concrete (m³)</th><th>Last Updated</th></tr></thead>
            <tbody>
              {structWithProgress.map(s => (
                <tr key={s.id}>
                  <td><strong>{s.structure_ref}</strong></td>
                  <td>{s.structure_type}</td>
                  <td>{s.chainage}</td>
                  <td>{s.side}</td>
                  <td>{s.stagesCompleted}</td>
                  <td>{s.lastStage || '-'}</td>
                  <td>{s.totalConcrete > 0 ? s.totalConcrete.toFixed(1) : '-'}</td>
                  <td>{s.lastDate || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
