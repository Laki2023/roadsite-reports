import React, { useState, useEffect } from 'react';
import { getProjects, getSiteIssues, updateSiteIssue } from '../lib/supabase';

export default function SiteIssuesPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all');
  const isAdmin = ['admin', 'super_admin', 'pm', 'engineer'].includes(profile.role);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);
  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      getSiteIssues(selectedProject).then(setIssues).catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  async function handleStatusChange(id, newStatus) {
    try {
      await updateSiteIssue(id, { status: newStatus, resolved_date: newStatus === 'Resolved' ? new Date().toISOString().split('T')[0] : null });
      const updated = await getSiteIssues(selectedProject);
      setIssues(updated);
    } catch (err) { alert(err.message); }
  }

  const filtered = filter === 'all' ? issues : issues.filter(i => {
    if (filter === 'open') return i.status === 'Open';
    if (filter === 'emergency') return i.is_emergency;
    return i.status === filter;
  });

  const openCount = issues.filter(i => i.status === 'Open').length;
  const emergencyCount = issues.filter(i => i.is_emergency && i.status === 'Open').length;

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>⚠️ Site Issues</h2>
        <p className="page-subtitle">Issues logged from daily reports. {isAdmin ? 'You can update status.' : 'Read-only view.'}</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <select value={filter} onChange={e => setFilter(e.target.value)}>
          <option value="all">All Issues</option>
          <option value="open">Open ({openCount})</option>
          <option value="emergency">Emergency ({emergencyCount})</option>
          <option value="Resolved">Resolved</option>
        </select>
      </div>

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view site issues.</p>
      ) : filtered.length === 0 ? (
        <p className="empty">No issues found.</p>
      ) : (
        <div className="issues-list">
          {filtered.map(issue => (
            <div key={issue.id} className={`issue-card severity-${issue.severity?.toLowerCase()} ${issue.is_emergency ? 'emergency' : ''}`}>
              <div className="issue-header">
                <div>
                  {issue.is_emergency && <span className="emergency-tag">🚨 EMERGENCY</span>}
                  <span className={`severity-tag sev-${issue.severity?.toLowerCase()}`}>{issue.severity}</span>
                  <span className="issue-category">{issue.category}</span>
                </div>
                <span className="issue-date">{issue.reported_date}</span>
              </div>
              <p className="issue-desc">{issue.description}</p>
              {issue.chainage && <div className="issue-meta">📍 Chainage: {issue.chainage}</div>}
              {issue.action_required && <div className="issue-meta">🔧 Action: {issue.action_required}</div>}
              <div className="issue-footer">
                <span className={`status-badge status-${issue.status?.toLowerCase()}`}>{issue.status}</span>
                {isAdmin && issue.status === 'Open' && (
                  <div className="issue-actions">
                    <button className="btn btn-sm" onClick={() => handleStatusChange(issue.id, 'In Progress')}>In Progress</button>
                    <button className="btn btn-sm btn-success" onClick={() => handleStatusChange(issue.id, 'Resolved')}>Resolve</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
