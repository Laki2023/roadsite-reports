import React, { useState, useEffect } from 'react';
import { getProjects, getWorksActivities, getWorksProgress, seedProjectActivities } from '../lib/supabase';

export default function WorksActivitiesPage({ profile }) {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [activities, setActivities] = useState([]);
  const [progress, setProgress] = useState([]);
  const [loading, setLoading] = useState(false);
  const isAdmin = ['admin', 'super_admin', 'pm', 'engineer'].includes(profile.role);

  useEffect(() => { getProjects().then(setProjects).catch(console.error); }, []);

  useEffect(() => {
    if (selectedProject) {
      setLoading(true);
      Promise.all([getWorksActivities(selectedProject), getWorksProgress(selectedProject)])
        .then(([a, p]) => { setActivities(a); setProgress(p); })
        .catch(console.error).finally(() => setLoading(false));
    }
  }, [selectedProject]);

  async function handleSeed() {
    const proj = projects.find(p => p.id === selectedProject);
    if (!proj) return;
    try {
      await seedProjectActivities(selectedProject, proj.category || 'Construction');
      const a = await getWorksActivities(selectedProject);
      setActivities(a);
    } catch (err) { alert(err.message); }
  }

  // Aggregate progress per activity
  const activityProgress = activities.map(act => {
    const entries = progress.filter(p => p.activity_id === act.id);
    const totalQty = entries.reduce((sum, e) => sum + (parseFloat(e.quantity_today) || 0), 0);
    const lastEntry = entries[0];
    return { ...act, totalQty, entryCount: entries.length, lastDate: lastEntry?.report_date };
  });

  const proj = projects.find(p => p.id === selectedProject);

  return (
    <div className="page-container">
      <div className="page-header">
        <h2>⛏️ Works Activities</h2>
        <p className="page-subtitle">Read-only dashboard — data populated from daily report submissions</p>
      </div>
      <div className="filter-bar">
        <select value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">Select project...</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {isAdmin && selectedProject && activities.length === 0 && (
          <button className="btn btn-primary" onClick={handleSeed}>Auto-Generate Activities ({proj?.category || 'Construction'})</button>
        )}
      </div>

      {loading ? <div className="loading"><div className="spinner" /></div> : !selectedProject ? (
        <p className="empty">Select a project to view works activities.</p>
      ) : activities.length === 0 ? (
        <p className="empty">No activities defined for this project. {isAdmin ? 'Click Auto-Generate to create the standard activity list.' : 'Ask your admin to generate activities.'}</p>
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>#</th><th>Activity</th><th>Unit</th><th>Total Qty</th><th>Reports</th><th>Last Entry</th><th>Status</th></tr></thead>
            <tbody>
              {activityProgress.map((a, i) => (
                <tr key={a.id}>
                  <td>{i + 1}</td>
                  <td><strong>{a.name}</strong></td>
                  <td>{a.unit}</td>
                  <td>{a.totalQty > 0 ? a.totalQty.toFixed(1) : '-'}</td>
                  <td>{a.entryCount}</td>
                  <td>{a.lastDate || '-'}</td>
                  <td><span className={`status-badge status-${(a.status || 'not-started').toLowerCase().replace(/\s/g, '-')}`}>{a.status || 'Not Started'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
